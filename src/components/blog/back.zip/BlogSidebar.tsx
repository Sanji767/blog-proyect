// src/components/blog/BlogSidebar.tsx
import Link from "next/link";
import { getCategories } from "@/lib/blog/getCategories";
import { getTags } from "@/lib/blog/getTags";
import type { Category } from "@/content/categories";
import type { Tag } from "@/content/tags";

export default function BlogSidebar({
  currentSlug,
}: {
  currentSlug?: string;
}) {
  const categories: Category[] = getCategories();
  const tags: Tag[] = getTags();

  return (
    <aside className="space-y-6">
      {/* Categorías */}
      <section className="rounded-2xl border bg-background p-4">
        <h3 className="text-sm font-bold mb-3">Categorías</h3>

        <div className="space-y-1.5">
          {categories.map((c: Category) => (
            <Link
              key={c.slug}
              href={`/blog/categoria/${c.slug}`}
              className="block rounded-lg px-3 py-2 text-sm hover:bg-muted"
            >
              {c.title}
            </Link>
          ))}
        </div>
      </section>

      {/* Tags */}
      <section className="rounded-2xl border bg-background p-4">
        <h3 className="text-sm font-bold mb-3">Tags</h3>

        <div className="flex flex-wrap gap-2">
          {tags.map((t: Tag) => (
            <Link
              key={t.slug}
              href={`/blog/tag/${t.slug}`}
              className="rounded-full border px-3 py-1 text-xs hover:bg-muted"
            >
              {t.title}
            </Link>
          ))}
        </div>
      </section>
    </aside>
  );
}
